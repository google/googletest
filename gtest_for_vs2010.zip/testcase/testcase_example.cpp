
#include "gtest/gtest.h"

#include "source_example.h"

TEST(test_add, test_add_integer)
{
    int a =1, b=2;

    ASSERT_EQ(3, add(a, b));
}