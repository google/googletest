#!/usr/bin/env bash

echo "Running tool wrapper"
